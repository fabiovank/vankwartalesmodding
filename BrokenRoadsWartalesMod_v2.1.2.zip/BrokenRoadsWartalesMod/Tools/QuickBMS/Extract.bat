QuickBMS.exe -G -w Script.bms ../res.pak ../modded
