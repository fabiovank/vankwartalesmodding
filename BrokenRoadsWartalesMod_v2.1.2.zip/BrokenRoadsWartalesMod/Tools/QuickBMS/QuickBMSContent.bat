quickbms_4gb_files.exe -G -w ScriptContent.bms ../assets.pak ../assets


