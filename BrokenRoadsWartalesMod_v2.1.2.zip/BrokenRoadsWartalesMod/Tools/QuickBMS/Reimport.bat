QuickBMS.exe -G -w -r -r Script.bms ../res.pak ../modded
